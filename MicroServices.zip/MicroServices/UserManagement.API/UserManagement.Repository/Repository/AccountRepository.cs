﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using UserManagement.Context.DTO.Identity;
using UserManagement.Model.Model;
using UserManagement.Model.ResponseModel;
using UserManagement.Repository.IRepository;
using UserManagement.Service.IService;

namespace UserManagement.Repository.Repository
{
    public class AccountRepository:IAccountRepository
    {
        private readonly IAccountService _accountService;
        public AccountRepository(IAccountService accountService)
        {
            _accountService = accountService;
        }
        public async Task<ResponseModel> RegisterUserAsyn(RegistrationModel registration)
        {
            return await _accountService.RegisterUserAsyn(registration);
        }

        public async Task<ResponseModel> LoginAsyn(LoginModel login)
        {
            return await _accountService.LoginAsyn(login);
        }
        public async Task<ResponseModel> AddTasksAsyn(TaskDetailModel task)
        {
            return await _accountService.AddTasksAsyn(task);
        }
        public async Task<TaskDetailResponseModel> GetTaskDeatils()
        {
            return await _accountService.GetTaskDeatils();
        }
    }
}
