﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserManagement.Model.Model
{
    public class TaskDetailResponseModel
    {
        public List<TaskDetailModel>? Data { get; set; }
        public string? Message { get; set; }
        public int StatusCode { get; set; }
        public int TotalCount { get; set; }
        public string? Token { get; set; }
        public bool Status { get; set; }
    }
}
