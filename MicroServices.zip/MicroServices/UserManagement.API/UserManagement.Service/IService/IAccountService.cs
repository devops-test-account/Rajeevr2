﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagement.Model.Model;
using UserManagement.Model.ResponseModel;

namespace UserManagement.Service.IService
{
    public interface IAccountService
    {
        Task<ResponseModel> RegisterUserAsyn(RegistrationModel registration);
        Task<ResponseModel> LoginAsyn(LoginModel login);
        Task<ResponseModel> AddTasksAsyn(TaskDetailModel task);
        Task<TaskDetailResponseModel> GetTaskDeatils();
    }
}
