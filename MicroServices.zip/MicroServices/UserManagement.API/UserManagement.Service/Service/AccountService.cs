﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using UserManagement.Context.DTO.Core;
using UserManagement.Context.DTO.Identity;
using UserManagement.Context.TestingDbContext;
using UserManagement.Model.Model;
using UserManagement.Model.ResponseModel;
using UserManagement.Service.IService;

namespace UserManagement.Service.Service
{
    public class AccountService:IAccountService
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IConfiguration _configuration;
        private readonly TestingDBContext _testingdbContext;
        public AccountService(UserManager<ApplicationUser> userManager, IConfiguration configuration, RoleManager<IdentityRole> roleManager,TestingDBContext testingDBContext)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _configuration = configuration;
            _testingdbContext = testingDBContext;
        }
        public async Task<ResponseModel> RegisterUserAsyn(RegistrationModel registration)
        {
            ResponseModel response = new ResponseModel();
            try
            {

                var userExists = await _userManager.FindByNameAsync(registration.UserName);
                if (userExists != null)
                {
                    response.Message = "Admin already Exists";
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
                else
                {
                    ApplicationUser applicationUser = new ApplicationUser()
                    {
                        UserName = registration.UserName,
                        Email = registration.Email,
                        SecurityStamp = Guid.NewGuid().ToString()
                    };
                    var data = await _userManager.CreateAsync(applicationUser, registration.Password);
                    if (data.Succeeded)
                    {
                        if (!await _roleManager.RoleExistsAsync(UserRoles.Admin))
                            await _roleManager.CreateAsync(new IdentityRole(UserRoles.Admin));


                        if (await _roleManager.RoleExistsAsync(UserRoles.Admin))
                        {
                            await _userManager.AddToRoleAsync(applicationUser, UserRoles.Admin);
                        }

                        response.Data = applicationUser;
                        response.Message = "User Added Successfully";
                        response.StatusCode = (int)HttpStatusCode.Created;
                    }
                    else
                    {
                        response.Data = "Failed data";
                        response.Message = "Failed Data" + ":" + data;
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                    }

                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.Message = ex.Message.ToString();
                response.StatusCode = (int)HttpStatusCode.BadRequest;
            }

            return response;
        }

        private async Task<bool> AssignRole(UserRole userRole)
        {
            bool isRoleAssigned = false;
            try
            {

                var role = _roleManager.FindByNameAsync(userRole.RoleName).Result;
                var registeredUser = _userManager.FindByIdAsync(userRole.UserId).Result;//FindByNameAsync(userRole.UserId).Result;
                if (role != null)
                {
                    var data = await _userManager.AddToRoleAsync(registeredUser, role.Name);
                    if (data.Succeeded)
                    {
                        isRoleAssigned = true;
                    }
                    else
                    {
                        isRoleAssigned = false;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return isRoleAssigned;
        }
        public async Task<ResponseModel> LoginAsyn(LoginModel login)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var Email = await _userManager.FindByEmailAsync(login.Email);
                if (Email != null && await _userManager.CheckPasswordAsync(Email, login.Password))
                {
                    var userRole = await _userManager.GetRolesAsync(Email);
                    response.Token = GenerateTokenJWT(login.Email, login.Password);
                    response.Data = login;
                    response.Message = "Login Successfully";
                    response.StatusCode = (int)HttpStatusCode.OK;
                }

            }
            catch (Exception ex)
            {

                response.Data = null;
                response.Message = ex.Message;
                response.StatusCode = (int)HttpStatusCode.BadRequest;
            }
            return response;
        }
        public string GenerateTokenJWT(string Email, string Password)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier,Email),
                new Claim(ClaimTypes.Email,Password)
            };
            var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims,
                expires: DateTime.UtcNow.AddMinutes(15),
                signingCredentials: credentials);
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public async Task<ResponseModel> AddTasksAsyn(TaskDetailModel taskDetailModel)
        {
            ResponseModel response = new ResponseModel();

            var taskdetailsData = new TaskDetails
            {

                UserId= taskDetailModel.UserId,
                TaskName= taskDetailModel.TaskName,
                TaskDescription = taskDetailModel.TaskDescription,
                TaskStatus = taskDetailModel.TaskStatus
            };

            await _testingdbContext.TaskDetails.AddAsync(taskdetailsData);
            await _testingdbContext.SaveChangesAsync();

       
            response.Data = taskDetailModel;
            response.StatusCode = (int)HttpStatusCode.OK;
            response.Message = "Added Successfully";

            return response;
        }
        public async Task<TaskDetailResponseModel> GetTaskDeatils()
        {
            var response = new TaskDetailResponseModel();
            var taskDetailModel = new List<TaskDetailModel>();
            var getTaskDetail = await _testingdbContext.TaskDetails.ToListAsync();
            foreach (var item in getTaskDetail)
            {
                taskDetailModel.Add(new TaskDetailModel()
                {
                    TaskId = item.TaskId,
                    TaskName = item.TaskName,
                    TaskDescription= item.TaskDescription,
                    TaskStatus= item.TaskStatus
                });
            }
            response.Status = true;
            response.Data = taskDetailModel;
            response.StatusCode = (int)HttpStatusCode.OK;
            response.Message = "";

            return response;
        }
    }
       
}
