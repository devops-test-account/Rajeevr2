﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagement.Context.DTO.Core;
using UserManagement.Context.DTO.Identity;

namespace UserManagement.Context.TestingDbContext
{
    public class TestingDBContext : IdentityDbContext<ApplicationUser>
    {
        public TestingDBContext(DbContextOptions<TestingDBContext> options) : base(options)
        {

        }
        //protected override void OnModelCreating(ModelBuilder builder)
        //{
        //    base.OnModelCreating(builder);
        //}
        public DbSet<TaskDetails> TaskDetails { get; set; }
    }
}
