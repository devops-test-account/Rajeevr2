﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.Metrics;
using System.Security.Claims;
using UserManagement.Model.Model;
using UserManagement.Model.ResponseModel;
using UserManagement.Repository.IRepository;

namespace UserManagement.API.Controllers
{
    [ApiController]
    public class AccountController : Controller
    {
        // private readonly IAccountService _accountService;
        private readonly IAccountRepository _accountRepository;
        private readonly ILogger<AccountController> _logger;
        public AccountController(IAccountRepository accountRepository, ILogger<AccountController> logger)
        {
            _accountRepository = accountRepository;
            _logger = logger;
        }
        [HttpPost]
        [Route("RegisterUser")]
        public async Task<IActionResult> RegisterUser(RegistrationModel registration)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel = await _accountRepository.RegisterUserAsyn(registration);
            var result = responseModel.Data;
            if (result != null)
            {
                return Ok(responseModel);
            }
            else
            {
                return BadRequest();
            }
        }
        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login(LoginModel login)
        {
            try
            {
                if (!string.IsNullOrEmpty(login.Email) && !string.IsNullOrEmpty(login.Password))
                {
                    var result = await _accountRepository.LoginAsyn(login);
                    return Ok(result);
                }
                return NotFound("Not Found");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        [Route("AddTasks")]
        public async Task<IActionResult> AddTasks(TaskDetailModel task)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel=await _accountRepository.AddTasksAsyn(task);
            var result = responseModel.Data;
            if(result != null)
            {
                return Ok(responseModel);
            }
            else
            {
                return BadRequest();
            }
        }
        [HttpGet]
        [Route("GetTaskDeatils")]
        public async Task<IActionResult> GetTaskDeatils()
        {
         
            var response = await _accountRepository.GetTaskDeatils();
            if (response.Status)
            {
                return Ok(response);
            }
            return NotFound(response);
        }

    }
}
